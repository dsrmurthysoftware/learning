//Component Life Cycle
import { 
  Component,
  Input,
  OnInit,OnChanges,DoCheck,OnDestroy,
  ChangeDetectorRef} from '@angular/core';

// Parent component
@Component({
  selector: 'app-lifecycle',
  template: `
    <h1 class="container">Google Search:
        <input type="text" [(ngModel)]="search">
     </h1>

    <child [search]="search"></child>
  `
})
export class CompLifeCycleComponent {
  search: string = '';
}

//child component
@Component({
  selector: 'child',
  template: `
  <h1 class='text-danger container'>Search Text</h1>
  <div class='well'>
   <h3 class='text-primary'>{{search}}</h3>
  </div>
    `
})
export class ChildComponent 
            implements OnInit,OnChanges,DoCheck,OnDestroy { 
  changed:boolean=false;  
  @Input() search: string;
  
  /** search isn't initialized yet */
  constructor(public cd:ChangeDetectorRef) {
    // inject service here
    console.log(`constructor: ${this.search}`);
    this.cd.detach();
  }  

 ngOnInit() {
   // invoke service method for initial data, load data from localstorage
    console.log(`ngOnInit: ${this.search}`);
    /*
    // raise custom events
    setTimeout(() => {
      this.cd.reattach()
    },5000); 
    */
  }
  /*Invoked every time an @Input() property changes via the data binding */
  ngOnChanges() {
   // invoke service method to handle changes
    console.log(`ngOnChanges: ${this.search}`);     
  }  

  ngDoCheck() {
    // Write custom change detection strategy logic here
    console.log("ngDoCheck- Change detection strategy")
    //to re-render even it is detached in constructor 
  if(this.search.length>3){
   this.cd.detectChanges();  // $spply()
  }
   this.cd.checkNoChanges();//safe guard changes
  }  
  ngOnDestroy() {
    // Remove the component state here, unsubscribe observer,log
    console.log("Component Destroyed");
  }
}//end
