/*
import { TestBed, ComponentFixture, async } from '@angular/core/testing';
import { MyApp } from './app.component';
import { LoginPage } from '../pages/login/login';
  
let comp: MyApp;
let fixture: ComponentFixture<MyApp>;
  
describe('Component: Root Component', () => {
  
    beforeEach(async(() => {
  
        TestBed.configureTestingModule({
  
            declarations: [MyApp],
  
            providers: [
  
            ],
  
            imports: [
                AuthModule.forRoot(MyApp)
            ]
  
        }).compileComponents();
  
    }));
  
    beforeEach(() => {
  
        fixture = TestBed.createComponent(MyApp);
        comp    = fixture.componentInstance;
  
    });
  
    afterEach(() => {
        fixture.destroy();
        comp = null;
    });
 
    it('some thing should happen when we do some thing', () => {
 
        someObject.doSomething();      
 
        expect(someThing).toBe(thisValue);
 
    });

//-------------------
//for Async testing
it('some thing should happen when we do some thing', () => {
 
    let flag = false;
 
    let testPromise = new Promise((resolve) => {
        // do some stuff
    });
 
    testPromise.then((result) => {
        flag = true;
    });    
 
    expect(flag).toBe(true);
 
});
});

When a test is running within a fakeAsync zone, 
we can use two functions called flushMicrotasks and tick. 

The tick function will advance time by a specified number of 
milliseconds, so tick(100) would execute any asynchronous tasks 
that would occur within 100ms. 

The flushMicrotasks function will clear any microtasks that are currently in the queue.
  
example:

it('should test some asynchronous code', fakeAsync(() => {
    let flag = false;
    setTimeout(() => { flag = true; }, 100);
    expect(flag).toBe(false); // PASSES
    tick(50);
    expect(flag).toBe(false); // PASSES
    tick(50);
    expect(flag).toBe(true); // PASSES
}));

or

it('should test some asynchronous code', fakeAsync(() => {
 
    let flag = false;
 
    Promise.resolve(true).then((result) => {
        flag = true;
    });
 
    flushMicrotasks(); //or tick()
 
    expect(flag).toBe(true); // PASSES
 
}));

For 2 promises:
t('should test some asynchronous code', fakeAsync(() => {
 
        let flagOne = false;
        let flagTwo = false;
 
        Promise.resolve(true).then((result) => {
            flagOne = true;
        });
 
        Promise.resolve(true).then((result) => {
            flagTwo = true;
        });
 
        flushMicrotasks();
 
        expect(flagOne).toBe(true); // PASSES
        expect(flagTwo).toBe(true); // PASSES
 
}));

For Observables:
it('should test some asynchronous code', fakeAsync(() => {
 
    let testObservable = Observable.of(Promise.resolve(true));
 
    let flag = false;
 
    testObservable.subscribe((result) => {
        flag = true;
    });
 
    flushMicrotasks();
 
    expect(flag).toBe(true); // PASSES
 
}));

it('should return an Observable<Array<Video>>',
  inject([VideoService], (videoService) => {

    videoService.getVideos().subscribe((videos) => {
      expect(videos.length).toBe(4);
      expect(videos[0].name).toEqual('Video 0');
      expect(videos[1].name).toEqual('Video 1');
      expect(videos[2].name).toEqual('Video 2');
      expect(videos[3].name).toEqual('Video 3');
    });
}))
*/