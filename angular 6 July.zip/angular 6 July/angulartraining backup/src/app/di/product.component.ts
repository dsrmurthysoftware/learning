import { Component }      from '@angular/core';
import {Product} from './product'
import {ProductService} from "./product.service";

@Component({
  selector: 'app-DI',
  providers:[ProductService],
  templateUrl:'./product.component.html',
  
})
export class ProductComponent {
  product: Product;
 ps:ProductService;
   // constructor level dependency injection
  constructor(ps: ProductService) {
       console.log("Service is injected")
      this.ps=ps; 
   }
   ngOnInit(){
     this.product=this.ps.getProduct();
   }
  
   
}


