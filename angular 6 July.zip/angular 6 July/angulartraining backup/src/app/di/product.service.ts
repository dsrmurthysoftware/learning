import {Injectable} from '@angular/core';
import {Product} from './product'

@Injectable()
export class ProductService  {

  //Service
  getProduct(): Product {
    return new Product
    ( 101, "iPhone 8", 1249.99, 
        "The latest iPhone, 9-inch screen");
    }   
}







/*
   1. Global level service injection
   2. Module level service injection
   3. Component level service injection
*/





/*
  Naming conventions:
    product.ts
    product.service.ts
    product.component.ts
    product.component.html
    product.component.css
    product.grid.directive.ts
    product-filter.pipe.ts
    product.module.ts
*/