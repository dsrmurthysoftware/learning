import { BrowserModule } from '@angular/platform-browser';
/* 
Contains the functionality to bootstrap the application in a browser. 
Includes everything DOM and browser related, pieces that help render into the DOM. 
*/

// contains Directives,Pipes,Annotations core services.
import { NgModule } from '@angular/core';

// for ng-model (Two way binding)
import {FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { StartComponent } from './start/start.component';


//binding
import {BindingComponent} from "./binding/binding.component";
import {NestedComponent} from "./binding/nested.component";

import {DebugComponent} from "./debug/debug.component"

//Working with IOModule
import {IOModule} from './input-output/input-output.module';

//Dependency Injection
import {DIModule} from './di/di.module';

import {ViewchildModule} from './viewchild/viewchild.module';

import {SkillsModule} from './skills/skills.module';

import {LoginModule} from './login/login.module';


import {CompLifeCycleComponent,ChildComponent} 
     from './complifecycle/comlifecycle.component';

     import { Service } from './dynamic/serviceLoader'
     import { DynamicComponent } from './dynamic/dynamic.component'

@NgModule({
  declarations: [
    AppComponent,
    StartComponent,
    BindingComponent,        
    NestedComponent,
    DebugComponent,
    CompLifeCycleComponent,
    ChildComponent,

    DynamicComponent   
  ],
  imports: [
    BrowserModule,FormsModule,
    IOModule,    
    DIModule,

    ViewchildModule,
    
    SkillsModule,
    LoginModule,

   
  ],
  providers: [Service],
  bootstrap: [AppComponent],
  entryComponents: [DynamicComponent]
})
export class AppModule { }
