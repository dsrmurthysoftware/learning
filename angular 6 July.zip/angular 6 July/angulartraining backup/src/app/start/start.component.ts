import { Component, OnInit,ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-start',
  templateUrl: './start.component.html',
  styleUrls: ['./start.component.css'],
  styles: [`
    h3 {
        text-decoration:underline;
        }
          `],
encapsulation: ViewEncapsulation.Emulated
})
export class StartComponent implements OnInit {
   time:any;
   name:string='Sriram';
   buttonStatus:boolean = false;
   titleStyle:string = 'red';
     
  constructor() {
     window.setInterval(() => {
                this.time=new Date().toString()
        }, 1000)
   }  
      //hook
  ngOnInit() {
    console.log("start component is initialized")
  }
// methods   - Event handlers
  Save(event:any){
    alert("Ok.. Your points are redeemed")
    this.buttonStatus=true
  }
}

/*
ViewEncapsulation.Native
  -component is isolated  from global styles

ViewEncapsulation.Emulated (default)
  Inherits Global styles and use its own style

ViewEncapsulation.None
Shadow DOM adds styles to <head> section and applied to
entire DOM.

*/


//https://developer.mozilla.org/en-US/docs/Web/Events


