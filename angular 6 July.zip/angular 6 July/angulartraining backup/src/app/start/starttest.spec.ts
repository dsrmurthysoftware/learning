import {StartComponent} from './start.component';
describe('Component: Start', () => {
  let component: StartComponent;
//beforeAll , afterAll   execute only once
  beforeEach(() => {   
    component = new StartComponent();
  });

  afterEach(() => { 
      component = null;
  });

  it('Component should return name', () => {    
    expect(component.name).toEqual('Sriram');
  });
  it("save button when clicked should return true",()=>{
      component.Save(null);
      var btnStatus=component.buttonStatus;
      expect(btnStatus).toBeTruthy();
      //expect(btnStatus).toBeFalsy();
  })
});
