import { Injectable } from '@angular/core';

@Injectable()
export class StartService {
    constructor(){
        console.log("I am service")
    }
}
