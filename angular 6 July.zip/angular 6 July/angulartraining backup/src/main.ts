import { enableProdMode } from '@angular/core';

/*
Contains implementations for the dynamic bootstrap of the application. 
it compile templates to render on client 
*/
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';

// configure for development or production mode
if (environment.production) {
  enableProdMode();
}

platformBrowserDynamic().bootstrapModule(AppModule);
