import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { MaterialModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// iin angular6 , replace Md with Mat and no MaterialModule

import { MdButtonModule, MdCardModule, MdMenuModule, 
         MdToolbarModule, MdIconModule} from '@angular/material'

import {PhotosComponent} from './photos.component';

import { AppComponent } from './app.component';
import { MyFormComponent } from './my-form/my-form.component';
@NgModule({
  declarations: [
    AppComponent,
    PhotosComponent,
     MyFormComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    MaterialModule,
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }