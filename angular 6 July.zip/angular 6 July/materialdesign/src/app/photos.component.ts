import { Component } from '@angular/core';
import {Http} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
//visit https://jsonplaceholder.typicode.com/photos


@Component({
  selector: 'app-photos',
  template: `
     <md-toolbar color='primary'>
       <span>Murthy Infotek</span>
       <span class='example-spacer'></span>
       <button md-button  [mdMenuTriggerFor]='appMenu'>
           <md-icon>menu</md-icon>Menu
       </button>
     </md-toolbar>  

     <md-menu #appMenu="mdMenu">
     <button md-menu-item>Settings</button>
     <button md-menu-item>Help</button>
     </md-menu>

  <md-card  class="example-card"
      *ngFor="let data of (myData ? myData.slice(0,10):[]);let i=index">

      <img  md-card-image src="{{data.url}}">
       <md-card-header>
          <md-card-title> {{data.title}} ></md-card-title>
       </md-card-header> 

      <md-card-actions>
        <button  md-button>LIKE</button>
        <button md-button> SHARE </button> 
      </md-card-actions>

   </md-card>
  `
})
export class PhotosComponent {
  myData :Array<any>;
  constructor(private http:Http){
  	this.http.get('https://jsonplaceholder.typicode.com/photos')
  	.map(response => response.json())
  	.subscribe (res=> this.myData=res);
  }
}
