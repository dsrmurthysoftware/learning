import { Component, ViewContainerRef } from '@angular/core';

@Component({
  selector: 'app-mypost',
  template: ''
})
export class MyPostComponent {
   constructor(public viewContainerRef: ViewContainerRef) { }
}    