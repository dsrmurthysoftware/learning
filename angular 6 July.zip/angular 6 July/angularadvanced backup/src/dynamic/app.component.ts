import { Component } from '@angular/core';

@Component({
   selector: 'app-root',
   template: `
			   <post-banner></post-banner>	
             `
})
export class AppComponent { 
}
    