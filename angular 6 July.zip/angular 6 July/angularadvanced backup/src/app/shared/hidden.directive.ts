// ./app/shared/hidden.directive.ts
//load DOM specific helpers
import { Directive, ElementRef, Input, Renderer } 
       from '@angular/core';
import { DomElementSchemaRegistry } from '@angular/compiler';

@Directive({ selector: '[myHidden]' })
export class HiddenDirective  {
    constructor(public el: ElementRef, 
    	             public renderer: Renderer) {}

    @Input() myHidden: boolean;
    
    ngOnInit(){
      console.log(this.myHidden);
        if(this.myHidden) {
           console.log(this.el.nativeElement)            
           this.renderer.setElementStyle(
                     this.el.nativeElement, 'display', 'none' );
          
        }
    }
}



