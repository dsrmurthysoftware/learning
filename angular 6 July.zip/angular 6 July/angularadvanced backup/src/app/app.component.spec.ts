import { TestBed, async } from '@angular/core/testing';

import { AppComponent } from './app.component';

describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent
      ],
    }).compileComponents();
  }));

  it("Name should contain Murthy",async(()=>{
    const app= new AppComponent();
    expect(app.name).toEqual('Murthy');
  }));
});
