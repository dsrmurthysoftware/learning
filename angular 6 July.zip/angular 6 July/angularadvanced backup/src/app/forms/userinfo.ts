export interface UserInfo{
    userName:string,
    password:string
    
}