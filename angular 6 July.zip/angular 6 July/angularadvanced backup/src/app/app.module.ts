import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';

import {ContactModule} 
      from './multicomp/contact.module'

import {LoginModule} from './login/login.module';

//Directives and Pipes
import {SharedModule} from './shared/shared.module';

import {JqueryComponent} from './jquerydemo/jquerydemo.component';

import {AppPipeComponent} from './http/asyncpipe.component';
import {AsyncPipeComponent} from './http/asyncpipe.component';

import { ReactiveFormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http';

import {JsonpModule} from '@angular/http';


import {WeatherComponent} from './http/http.component';


import {MusicComponent}  from './http/music.component';
//RouterGurad module
import {GuardModule} from './router-guard/guard-module';

import {BankModule} from './multimodules/bank/bank.module';

import {FormBuilderAppComponent,FormAppComponent}
   from './forms/formbuilder.example'

import {FormBuilderComponent} from 
   './forms/formbuilder.component'


//Dynamic Injection of Component
import {HomeModule} from './dynamicinjection/home/home.module'

//import {NewLoginModule} from './forms/newlogin.module';
import { DummyComponent } from './dummy/dummy.component'

import {HttpCRUDModule} from './http-crud/http-crud.module'
@NgModule({
  declarations: [
    AppComponent,    
    WeatherComponent,
    MusicComponent,
    JqueryComponent,

    FormBuilderComponent,
   
   FormBuilderAppComponent,
   FormAppComponent,
   DummyComponent,

   AppPipeComponent,
   AsyncPipeComponent
  ],
  imports: [
    BrowserModule,    
     FormsModule,
     ContactModule,
     HttpModule,
     ReactiveFormsModule,  
     
     JsonpModule,
    
     HttpCRUDModule,
    

    ContactModule,

    SharedModule,

    LoginModule,

    GuardModule,

    BankModule ,
    HomeModule,
   // NewLoginModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
