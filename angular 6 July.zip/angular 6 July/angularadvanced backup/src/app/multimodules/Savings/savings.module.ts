import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SavingsComponent } from './savings.component';
import { SavingsService } from './savings.service';

@NgModule({
    imports: [CommonModule],
    declarations: [SavingsComponent],
    providers: [SavingsService],
    exports: [SavingsComponent]
})
export class SavingsModule { }
