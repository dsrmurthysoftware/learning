//Access modifiers public, private and protected
//default is public
//Ground variables (properties) and function (methods) that 
// are highly related

class Point1{
    private x:number;
    private y:number;
    //constructor(x:number,y:number){}
    constructor(x?:number,y?:number){// ? optional params
    this.x=x;
    this.y=y;
    }

    public draw(){
        console.log('x:'+this.x+'y:'+this.y);
    }
}
//var p=new Point();//error   - solution is optional parameters
var p1=new Point1(5,6);
p1.x=10;//error
p1.draw();
