//Typescript Demonstration
/*
Topics:
-------
Type annotations, Type Assertions, Inline Annotations
Arrow functions
interfaces
classes
constructors
inheritance
Access modifiers (public,private,protected,static)
properties
generics
modules

$ tsc --help
$ tsc --version
$ tsc main.ts 
$ node main.js 
*/

function logMsg(message){
    console.log(message);
}
var msg="Hello world";
logMsg(msg);
// javascript is valid typescript code.

//----------------------------------------
