class Demo {
   
    constructor(){
    console.log("I am constructor")
    }
    num_val:any = 10;      //instance variable (default is public)
    private age:number=30; // private variable
    static sval:number = 10;  //static field 
    storeNum(): void {  // instance method
        var local_num:number = 14;   //local variable 
    }
    //method
    getAge():void{
        console.log(this.age);
    }
}
console.log("Static data"+Demo.sval)   //static variable  
var obj = new Demo();
console.log("Instance value of num: " + obj.num_val) ;
//console.log(age);   //error
obj.getAge();
