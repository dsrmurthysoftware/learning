//enum
//var ColorRed=0;
//var ColorGreen=1;
//var ColorBlue=2;
//instead go for enum

enum Color {Red=0,Green=1,Blue=2};
var backgroundColor=Color.Red;
// observe javascript code
console.log(backgroundColor);

// tsc -d enum.ts             observe enum.d.ts (Type Declarations)