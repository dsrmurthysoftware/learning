class Point2{
    constructor(private _x?:number, private _y?:number){
 /// tsc will automatically create variables
    }
    draw(){
        console.log(this._x+ ': '+ this._y);
    }
    //properties
    set x(value){
        if(value<0){
            throw new Error('value can not be less than 0');
        }
        this._x=value;

    }
    get x(){
        return this._x;
    }
}
var p2=new Point2(1,2);
p2.x=10;// set 
console.log(p2.x); //get
p2.draw();