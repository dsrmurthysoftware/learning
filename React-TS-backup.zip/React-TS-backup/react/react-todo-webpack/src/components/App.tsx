import * as React from "react"; // Typescript compiler expects React object for type safety

// React.Component<props,state>{}
export class App extends React.Component<{}, IState> {
  constructor(props: {}) {
    super(props);

   // Initial state for the component 
    this.state = {
      currentTask: "",
      tasks: []
    };
  }

  public handleSubmit(e: React.FormEvent<HTMLFormElement>): void {
    e.preventDefault();
   
    // Update the state with ES6 syntax
    this.setState({
      currentTask: "",
      tasks: [
        ...this.state.tasks,  // ES6 ... operator takes the current state and add new state
        {
          id: this._timeInMilliseconds(), // helper method 
          value: this.state.currentTask,
          completed: false
        }
      ]
    });
  }

  // remove the task from the list
  public deleteTask(id: number): void {
    const tasks: Array<ITask> = this.state.tasks.filter(
      (task: ITask) => task.id !== id
    );
    this.setState({ tasks });
  }

  // Toggle the task
  public toggleDone(index: number): void {
    let task: ITask[] = this.state.tasks.splice(index, 1);
    task[0].completed = !task[0].completed;
    const tasks: ITask[] = [...this.state.tasks, ...task];
    this.setState({ tasks });
  }

  //render always return JSX.Element[]
  public renderTasks(): JSX.Element[] {
    return this.state.tasks.map((task: ITask, index: number) => {
      return (
        <div key={task.id} className="tdl-task">
          <span className={task.completed ? "is-completed" : ""}>{task.value}</span>
          <button onClick={() => this.deleteTask(task.id)}>Delete</button>
          <button onClick={() => this.toggleDone(index)}>{task.completed ? "Undo" : "Done"}</button>
        </div>
      );
    });
  }

  public render(): JSX.Element {
    console.log(this.state); // for debugging
    return (
      <div>
        <h3>React with Typescript by Murthy</h3>
        <form onSubmit={e => this.handleSubmit(e)}>
          <input
            type="text"
            className="tdl-input"
            placeholder="Add a Task"
            value={this.state.currentTask}
            onChange={e => this.setState({ currentTask: e.target.value })}
          />
          <button type="submit">Add Task</button>
        </form>
        <section>{this.renderTasks()}</section>
      </div>
    );
  }

  // helper method must be private
  private _timeInMilliseconds(): number {
    const date: Date = new Date();
    return date.getTime();
  }
}

//Model state
interface IState {
  currentTask: string;
  tasks: Array<ITask>;
}

// Model state
interface ITask {
  id: number;
  value: string;
  completed: boolean;
}
