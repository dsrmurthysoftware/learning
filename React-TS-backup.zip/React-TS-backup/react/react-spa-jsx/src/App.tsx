import * as React from 'react';

import './App.css';

import logo from './logo.svg';
// import Grid from './propsandstate/Grid'

import HomePage from './start/Home';

import StateDemo from './propsandstate/StateDemo'

const uname:string="Murthy";
class App extends React.Component{
  public render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">React with Typescript by {uname}</h1>
        </header>

        <section className="dashboard">
          <HomePage />
          <StateDemo/>
        </section>

        <footer className="footer">
            <h3>Copyright Reserved to Murthy</h3>
        </footer>
      </div>
    );
  }
}

export default App;
