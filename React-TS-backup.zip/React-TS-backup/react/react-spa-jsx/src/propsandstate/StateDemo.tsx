import * as React from 'react';


interface IState{
    activities:any,
    currentActivity:string,
}


export default class StateDemo extends React.Component<{},IState>{
    constructor(props:{}){
        super((props));

        this.state={
            activities:[],
            currentActivity:""            
        }
    }

    public handleSubmit(e:React.FormEvent<HTMLFormElement>):void{
        e.preventDefault();
        this.setState({
            currentActivity:"",
            activities:[
                ...this.state.activities, this.state.currentActivity
            ]                     
        })
    }

    public renderActivities(): JSX.Element[] {
        return this.state.activities.map((str:string,index:number)=>{
            return (
                <div key={index}>{str}</div>
            )
        })
    }
    public render(): JSX.Element{
        console.log(this.state)
            return(
            <div>
                <h1>Activities to be Done</h1>
                <form onSubmit={(e)=> this.handleSubmit(e)}>
                    <input type="text"  placeholder="Add activity"
                    value={this.state.currentActivity}
                    onChange={(e)=>this.setState({currentActivity: e.target.value})}/>
                    <button type="submit">Add Activity</button>
                </form>
                <p>{this.renderActivities()}</p>
            </div>
        )
    }
}

