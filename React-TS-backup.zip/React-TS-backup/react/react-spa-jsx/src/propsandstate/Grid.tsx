import * as React from 'react';

export default class Grid extends React.Component<any,any>
{
    constructor(props:any){
        super(props)
    }
    /**
     * Render
     *
     * @returns {XML}
     */
    public render()
    {
        // build the users list
        const users:any= [];
        for (let i=1; i<10; i++) {
            users.push({
                id: i,
                job: 'Employee ' + i,
                username: 'Murthy ' + i,                
            });
        }

        // render
        return(
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Job</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    {users.map((user:any, index:number) => {
                        return(
                            <tr key={user.id}>
                                <td>#{user.id}</td>
                                <td>{user.username}</td>
                                <td>{user.job}</td>
                                <td>
                                    <a href={'/user-edit/' + user.id}>
                                        Edit
                                    </a>
                                </td>
                                <td>
                                    <button data-id={user.id}>Delete</button>
                                </td>
                            </tr>
                        );
                    })}
                </tbody>
            </table>
        );
    }
}