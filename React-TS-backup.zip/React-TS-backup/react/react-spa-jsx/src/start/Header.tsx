import * as React from 'react';

export default class Header extends React.Component<any,any> {
  constructor(props:{}){
    super(props)

  }  
 public render() {
    return (
      <div >         
          <h1>{this.props.company}</h1>          
       </div>
    );
  }
}