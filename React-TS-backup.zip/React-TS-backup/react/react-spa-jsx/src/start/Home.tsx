import * as React from 'react';
import Header from './Header';

export default class HomePage extends React.Component<any,any> {
   public render() {
    return (
            <div>
              <Header company="Murthy Infotek IT Services"/>
              <h1>Welcome to the Murthy Website!</h1>               
            </div>
    
    );
  }
}


