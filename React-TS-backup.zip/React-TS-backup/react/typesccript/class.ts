//Ground variables (properties) and function (methods) that 
// are highly related

class Point{
    x:number;
    y:number;
    //constructor(x:number,y:number){}
    constructor(x?:number,y?:number){// ? optional params
    this.x=x;
    this.y=y;
    }
    draw(){
        console.log('x:'+this.x+'y:'+this.y);
    }
}
//var p=new Point();//error   - solution is optional parameters
var p=new Point(5,6);
p.x=8;
p.draw();