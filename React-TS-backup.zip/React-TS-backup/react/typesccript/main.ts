
//Type annotation
var count = 5;
//count ='a';  // error, in  type script not allowed but fine in js
var x;

var a:number = 10;
var b:boolean;
var c:string;
var d:any;
var e:number[] = [1, 2, 3];
var f = [1, true, 'a', false];

//intellisence
var message="welcome"
var endsWithe=message.endsWith('e');
//---------------------------------------------

//Type assertion
var data;
data="Hello";
var endsWitho=data.endsWith('o');
//observe no intellisense as data in of type any (object) not string
// Solution is Type asssertion
var result=(<string>data).endsWith('o');

var resultnew=(data as string).endsWith('o');
console.log(result);

//---------------------------------------

//Arrow function  (Lambda)
var doLog=(msg)=>console.log(msg);

//Custom types
// This is called inline annotations
var drawPoint=(Point:{x:number,y:number})=>{
   console.log(Point.x+ ':'+ Point.y)
}

drawPoint({
    x:1,y:2
})

//instead of above code , convert to interface
interface Point{
    x:number,
    y:number
}
var draw=(p:Point)=>{
    console.log(p.x + ':'+p.y)
}
var p:Point= { x: 1, y: 2 };
draw(p);
