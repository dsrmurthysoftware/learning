var Demo = (function () {
    function Demo() {
        this.num_val = 10;
        this.age = 30;
        console.log("I am constructor");
    }
    Demo.prototype.storeNum = function () {
        var local_num = 14;
    };

    //method
    Demo.prototype.getAge = function () {
        console.log(this.age);
    };
    Demo.sval = 10;
    return Demo;
})();
console.log("Static data" + Demo.sval);
var obj = new Demo();
console.log("Instance value of num: " + obj.num_val);

//console.log(age);   //error
obj.getAge();
