declare var ColorRed: number;
declare var ColorGreen: number;
declare var ColorBlue: number;
declare enum Color {
    Red = 0,
    Green = 1,
    Blue = 2,
}
declare var backgroundColor: Color;
