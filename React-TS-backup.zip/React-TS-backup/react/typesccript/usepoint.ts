import {Point} from './point';
var p=new Point(1,2);
p.draw();