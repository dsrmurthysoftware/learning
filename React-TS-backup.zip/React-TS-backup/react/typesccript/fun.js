function Emp(name,salary){
    this.name=name;
    this.salary=salary;
    this.showdetails=function(){
      console.log(this.name+"- "+salary)
    }
}

Emp.prototype.Manager=function(){
    this.salary=6000;
}
var e1= new Emp("murthy",4000);
e1.showdetails();
var e2= new Emp("kavitha",6000);
e1.salary=8000;