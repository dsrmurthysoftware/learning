//Typescript Demonstration
/*
Topics:
-------
Type annotations, 
Type Assertions
Inline Annotations
Arrow functions
interfaces
enum
classes
constructors
inheritance
Access modifiers (public,private,protected,static)
properties
generics
modules

$ tsc --version
$ tsc main.ts
*/
function log(message) {
    console.log(message);
}
var msg = "Hello world";
log(msg);
// javascript is valid typescript code.
//----------------------------------------
