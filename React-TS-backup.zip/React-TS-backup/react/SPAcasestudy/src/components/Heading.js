import React, { Component } from 'react';
export default class Heading extends Component {
  render() {
    return (
      <div className="head">
       <h1>React SPA by Murthy</h1>
      </div>
    );
  }
}


