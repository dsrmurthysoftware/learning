
import * as React from "react";
import UserComponent from './UserComponent';

let Logo ="https://logrocket.com/img/logo.png";

export default class FirstComponent extends React.Component <any,any> {
	
	render() {
		return (
			<div>
				{/* React components must have a wrapper node/element */}
				<h1>A React Component with Typescript</h1>
				<div>
					
					<img src={Logo} /> 
				</div>	
                <p>Testing Typescript with React</p>
			</div>
		);
	}
}

