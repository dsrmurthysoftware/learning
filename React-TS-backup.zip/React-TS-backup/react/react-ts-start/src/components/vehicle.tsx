import * as React from "react";

type Props = {
  vehicleType: "Car" | "Truck" | "Motorcycle",
  color: string,
  numWheels: 2 | 4,
  age: number,
};
type State = {};

export default class Vehicle extends React.Component<Props, State> {
  public render():any 
   {
     return(
    <div>
      <div>VehicleType: {this.props.vehicleType}</div>
      <div>Color: {this.props.color}</div>
      <div>Wheels: {this.props.numWheels}</div>
      <div>Age: {this.props.age}</div>
    </div>
     )
  }
}