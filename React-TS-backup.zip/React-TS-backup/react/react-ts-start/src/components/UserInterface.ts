export default interface User{
	name: string;
	age: number;
	address: string;
	dob: Date;
}
