# React's Children API

React.Children, which plays an important role on direct parent-to-child composition.


- Review of allowed child types
- The props.children prop structure
- Example: React.Children.only
- Example: React.Children.count
- Example: React.Children.map
- Building a SlideShow Component
- Example: React.Children.toArray
