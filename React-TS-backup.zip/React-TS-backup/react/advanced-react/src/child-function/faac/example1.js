/*
//Level1
import React from 'react'
import {Parent} from 'parentComponent'
function example(){
    return(
        <Parent>
          {param => (
             <div>
                 {param}
            </div>
          )}
        </Parent>
    )
}

//Level2
import LoggedUser from 'LoggedUser'
function  example(){
    return(
        <LoggedUser>
            {username =>(
                <div>{username}</div>
            ) }
          </LoggedUser>  
    )
}

//Level 3
// Now we can reuse child this function for different UI components.
import {LoginButton, LogoutButton} from 'ui'
import LoggedUser from 'LoggedUser'
function  example(){
    return(
        <LoggedUser>
            {username =>(
                <div>username ? <LoginButton/> :<LogoutButton/></div>
            ) }
          </LoggedUser>  
    )
}

*/