# Function as Child Components

“Function as Child Component” is a pattern where the parent component accepts a function as child, instead of a nested React Node. 

create a FaCC and use it for making information available to wrapped components.

- What are FaCC
- Ex: hypothetical use cases
- Basic structure of a function as child component
- Scroll Position FaCC
- Refactor and Possible effects with the Scroll Position FaCC

