Contexts : Level 1 
---------
To pass date in Component hierarchy, we need to pass data to each child
via props which is laborious. Solution is context.

It is like global variable/object/container to hold never changing data
like sessionID, AuthToken,Themes, locales etc.

Context makes it possible to pass data through the component hierarchy, without needing intermediate components to know about it. It can be useful for data that never (or rarely) change, such as theming and localization

Panel -->InternalPanel --> ContentPanel


- What is Context
- Example: The sample application
- Comparing with props
- Brief overview of potential problems
- Example: Providing a Context
- Example: Consuming a Context
- Example: Updating Context
