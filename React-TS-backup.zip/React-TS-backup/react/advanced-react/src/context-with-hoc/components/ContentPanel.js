import React, { Component} from 'react';

//GrandChild component
class ContentPanel extends Component {

  render() {
    //get the current context and apply with {locale.header}....
    const { locale } = this.context;
    return (
      <div className="contentPanel">
        <h1>{locale.header}</h1>
        <p>
          {locale.text}
        </p>
        <button>{locale.buttonLabel}</button>
        <footer>ContentPanel.js</footer>
      </div>
    );
  }
}

export default ContentPanel;
