import React, { Component} from 'react';
import Panel from './components/Panel';
import './App.css';

import en from './locales/en.json';
import pt from './locales/pt.json';

const locales = {en, pt};

class App extends Component {
  // first configure which properties accesible by children with Proptypes

  state = {
    currentLocale: 'en'
  }

 // This actually sets context properties in static context object
  getChildContext() {
    return {locale: locales[this.state.currentLocale]}
  }

  // on Button Click, change the locale
  changeLocale(locale){
    this.setState({currentLocale: locale})
  }

  render() {
    return (
      <div>
        <nav>
          <a onClick={() => this.changeLocale('en')}>🇺🇸</a>
          <a onClick={() => this.changeLocale('pt')}>🇧🇷</a>
        </nav>
        <Panel />
      </div>
    );
  }
}

export default App;
