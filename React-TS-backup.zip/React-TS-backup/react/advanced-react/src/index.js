import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
//import App from './App';

//import App from './hoc/App'
//import App from './react-child/App'
import App from './context-with-hoc/App'

import registerServiceWorker from './registerServiceWorker';

ReactDOM.render(<App />, document.getElementById('root'));
registerServiceWorker();
