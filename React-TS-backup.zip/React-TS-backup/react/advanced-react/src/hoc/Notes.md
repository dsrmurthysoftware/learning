# Higher Order Components - HOC

Higher Order Component is a function that accepts a component as parameter and returns another component that wraps it.

HOC encapsulate behavior and also reusable.

Using Load Indicator with HOC as it takes time to load REST data from server.

- What is a Higher Order Component
- Using Curried functions for configuration
- Manipulating Props

