import React, { Component } from 'react';
import './LoadingHOC.css';

/*
Simple HOC
const LoadingHOC = (WrappedComponent) => {
  return class LoadingHOC extends Component {

    return this.props.contacts.length===0 ? 
                 <div className="loader" /> : 
                 <WrappedComponent {...this.props}/>;
  }
export default LoadingHOC;
//But we are hardcoding contacts here which is bad (Not Flexible HOC)
*/

//Good practise
//validate correct props are passed or not
const isEmpty = (prop) => (
  prop === null ||
  prop === undefined ||
  (prop.hasOwnProperty('length') && prop.length === 0) ||
  (prop.constructor === Object && Object.keys(prop).length === 0)
);

//loadingProp parameter to make HOC reusable which can take any props
//This below line is called curried function in JS
const LoadingHOC = (loadingProp) => (WrappedComponent) => {
  return class LoadingHOC extends Component {
    componentDidMount(){
      this.startTimer = Date.now();
    }

    componentWillUpdate(nextProps){
      if(!isEmpty(nextProps[loadingProp])) {
        this.endTimer = Date.now();
      }
    }

    render() {
      const myProps = {
        loadingTime: ((this.endTimer - this.startTimer)/1000).toFixed(2),
      };
       
      return isEmpty(this.props[loadingProp]) ? 
                 <div className="loader" /> : 
                 <WrappedComponent {...this.props} {...myProps}/>;
    }
  }
}
export default LoadingHOC;
