import React, { Component, PropTypes } from 'react';
import SearchBar from './SearchBar';
import ContactList from './ContactList';
import LoadingHOC from './HOC/LoadingHOC'
import './ContactsApp.css';


class ContactsApp extends Component {
  state = {
    filterText: ''
  };


  handleUserInput = (searchTerm) => {
    this.setState({filterText: searchTerm})
  }

  render() {
    const { loadingTime } = this.props;
    return(
      <div className="contactApp">
        <SearchBar filterText={this.state.filterText}
                   onUserInput={this.handleUserInput} />
        <ContactList contacts={this.props.contacts}
                     filterText={this.state.filterText}/>
        <p>Loading time {loadingTime} seconds</p>
      </div>
    )
  }
}

//export default LoadingHOC(ContactsApp) or use decorator @LoadingHOC on top of class
// or export default LoadingHOC('contacts')(ContactsApp) or @LoadingHOC('contacts')
export default LoadingHOC('contacts')(ContactsApp);
