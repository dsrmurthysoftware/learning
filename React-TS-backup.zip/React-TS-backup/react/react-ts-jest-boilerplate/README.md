# React + TypeScript + Jest demo app

- `yarn install`
- `yarn start`
- `open http://localhost:3000`
