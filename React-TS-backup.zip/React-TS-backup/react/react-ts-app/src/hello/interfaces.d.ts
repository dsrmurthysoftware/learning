interface IHelloFormProps {
	name: string;
	handleChange(event: any): void;
}

interface IHelloContentProps {
	name: string;
}
