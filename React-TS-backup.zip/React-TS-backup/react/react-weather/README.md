# Show the Local Weather

![Screenshot](/media/screenshot.png)

freeCodeCamp Show the Local Weather built with React and Typescript

## User Stories

* I can see the weather in my current location.
* I can see a different icon or background image
* I can push a button to toggle between Fahrenheit and Celsius
