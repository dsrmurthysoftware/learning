
//export const API="http://api.openweathermap.org/data/2.5/weather?q=chennai&units=imperial"
//export const APIKEY='ca3f6d6ca3973a518834983d0b318f73'

//export const API = 'https://http://api.wunderground.com/api/';
//export const APIKEY = 'ADD API KEY HERE';

export const API="https://api.wunderground.com/cgi-bin/findweather/getForecast?query=chennai"