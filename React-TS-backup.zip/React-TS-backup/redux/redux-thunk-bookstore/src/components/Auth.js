import React, { Component } from 'react';
import { connect } from 'react-redux';
import { getUser } from '../actions/user';
import { Button } from 'semantic-ui-react'

class Auth extends Component {
  render() {
    const { user, getUser } = this.props
    // object destructuring  in ES6
    return (
      <div>
      <h1>Murthy's Books Store</h1>
      <Button onClick={getUser}>
        { user? 'Logged' : 'Login' }
      </Button>      
      </div>
    )
  }
}

const mapStateToProps = (state) => {
  return { user: state.user };
}

const mapDispatchToProps = {
  getUser
}

export default connect(mapStateToProps, mapDispatchToProps)(Auth);
