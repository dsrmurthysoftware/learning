import React, { Component } from 'react';
import '../css/style.css';

import Header from './Header';
import Footer from './Footer'
export default class App extends Component {
  constructor(props){
    super(props)
  }
  render() {    
    return (
      <div className="text-center">       
          <Header company={this.props.company} />

          <div className="dashboard">
           <h1>Put your components here</h1>       
          </div>
          
          <Footer/>
      </div>
    );
  }
}
