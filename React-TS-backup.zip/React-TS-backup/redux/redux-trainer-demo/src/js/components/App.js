import React from 'react';
import TrainerList from '../containers/trainer-list';
import TrainerDetails from '../containers/trainer-details'
import '../../css/style.css';
import Header from '../Header';
import Footer from '../Footer';

//HOC - High Order Component
const App = () => (
    <div>
       <Header/>
            <h2>Trainers List- Murthy Infotek</h2>
            <TrainerList/>
            <hr />
            <h2>Trainer Details</h2>
            <TrainerDetails/>
        <Footer />
     </div>
);
export default App;