import React, { Component } from 'react';
import logo from '../assets/react.png';

export default class Header extends Component {
  constructor(props){
    super(props)
  }
  
  render() {
    return (
      <div className="text-center">
          <img  src={ logo } alt='React logo' />
          <h1 className="bg-primary">{this.props.company}</h1>
          <h2>React by Murthy</h2>
       </div>
    );
  }
}
/*
If we do not pass company prop, default prop will be taken
*/
Header.defaultProps={
  company:"Murthy Infotek"
}
