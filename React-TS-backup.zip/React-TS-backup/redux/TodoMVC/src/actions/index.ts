import * as types from '../constants/ActionTypes'
import { Todo } from '../models';
import { ACTION_TYPES } from '../constants/ActionTypes';

export interface IAction {
    type: ACTION_TYPES,
    text?: string,
    id?: number
}

export const addTodo = (text: string): IAction => ({ type: types.ADD_TODO, text })
export const deleteTodo = (id: number): IAction => ({ type: types.DELETE_TODO, id })
export const editTodo = (id: number, text: string): IAction => ({ type: types.EDIT_TODO, id, text })
export const completeTodo = (id: number): IAction => ({ type: types.COMPLETE_TODO, id })
export const completeAll = (): IAction => ({ type: types.COMPLETE_ALL })
export const clearCompleted = (): IAction => ({ type: types.CLEAR_COMPLETED })

export interface IActions {
    clearCompleted: () => void;
    completeAll: () => void;
    editTodo: (id: number, text: string) => void;
    completeTodo: (id: number) => void;
    addTodo: (text: string) => void;
    deleteTodo: (id: number) => void;
}