
import * as React from 'react'
import { bindActionCreators, Dispatch as ReduxDispatch } from 'redux'
import { connect } from 'react-redux'
import { Header } from '../components/Header'
import MainSection from '../components/MainSection'
import * as TodoActions from '../actions'
import { Todo } from '../models'

type Dispatch = ReduxDispatch<IStoreState>;

interface IAppProps {
  todos: Todo[];
}

interface IStoreState {
  todos: Todo[];
}

export interface IAppDispatchProps {
  actions: TodoActions.IActions;
}

type AppProps = IAppProps & IAppDispatchProps;

const App: React.StatelessComponent<AppProps> = (props: AppProps) => {
  return (
    <div>
      <Header addTodo={props.actions.addTodo} />
      <MainSection todos={props.todos} actions={props.actions} />
    </div>
  );
}

const mapStateToProps = (state: IStoreState) => ({
  todos: state.todos
})

const mapDispatchToProps = (dispatch: Dispatch): IAppDispatchProps => ({
  actions: {
    clearCompleted: () => { dispatch(TodoActions.clearCompleted()) },
    completeAll: () => { dispatch(TodoActions.completeAll()) },
    editTodo: (id: number, text: string) => { dispatch(TodoActions.editTodo(id, text)) },
    completeTodo: (id: number) => { dispatch(TodoActions.completeTodo(id)) },
    addTodo: (text: string) => { dispatch(TodoActions.addTodo(text)) },
    deleteTodo: (id: number) => { dispatch(TodoActions.deleteTodo(id)) }
  }
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(App)