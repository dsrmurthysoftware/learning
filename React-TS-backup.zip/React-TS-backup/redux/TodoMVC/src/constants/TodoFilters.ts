export type SHOW_ALL = 'show_all';
export const SHOW_ALL: SHOW_ALL = 'show_all';

export type SHOW_COMPLETED = 'show_completed';
export const SHOW_COMPLETED: SHOW_COMPLETED = 'show_completed';

export type SHOW_ACTIVE = 'show_active';
export const SHOW_ACTIVE: SHOW_ACTIVE = 'show_active';

export type SHOW_TYPES = SHOW_ALL | SHOW_COMPLETED | SHOW_ACTIVE;