import * as React from 'react'
import { Component } from 'react'
import TodoTextInput from './TodoTextInput'
import { IAppDispatchProps } from '../containers/App';
import todos from '../reducers/todos';
import { IAction } from '../actions';

export interface IHeaderProps {
  addTodo: (text: string) => void;
}

export const Header: React.StatelessComponent<IHeaderProps> = (props) => {

  const handleSave = (text: any) => {
    if (text.length !== 0) {
      props.addTodo(text)
    }
  };

  return (
    <header className="header">
      <h1>Projects</h1>
      <TodoTextInput newTodo
        onSave={handleSave}
        placeholder="what is your task?" />
    </header>
  );
}