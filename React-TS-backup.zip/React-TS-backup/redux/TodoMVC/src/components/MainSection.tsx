import * as React from 'react'
import { Component } from 'react'
import TodoItem from './TodoItem'
import Footer from './Footer'
import { SHOW_ALL, SHOW_COMPLETED, SHOW_ACTIVE, SHOW_TYPES } from '../constants/TodoFilters'
import { Todo } from '../models';
import * as TodoActions from '../actions'

const TODO_FILTERS = {
  [SHOW_ALL]: () => true,
  [SHOW_ACTIVE]: (todo: Todo) => !todo.completed,
  [SHOW_COMPLETED]: (todo: Todo) => todo.completed
}

interface IMainSectionProps {
  todos: Todo[];
  actions: TodoActions.IActions;
}

interface IMainSectionState {
  filter: SHOW_TYPES;
}

export default class MainSection extends React.Component<IMainSectionProps, IMainSectionState> {
  constructor(props: IMainSectionProps) {
    super(props);
    this.state = {
      filter: SHOW_ALL
    };
  }

  private handleClearCompleted = () => {
    this.props.actions.clearCompleted()
  }

  private handleShow = (filter: SHOW_TYPES) => {
    this.setState({ filter })
  }

  private renderToggleAll = (completedCount: number) => {
    const { todos, actions } = this.props
    if (todos.length > 0) {
      return (
        <span>
          <input className="toggle-all"
            type="checkbox"
            checked={completedCount === todos.length}
          />
          <label onClick={actions.completeAll} />
        </span>
      )
    }
  }

  private renderFooter = (completedCount: number) => {
    const { todos } = this.props
    const { filter } = this.state
    const activeCount = todos.length - completedCount

    if (todos.length) {
      return (
        <Footer completedCount={completedCount}
          activeCount={activeCount}
          filter={filter}
          onClearCompleted={this.handleClearCompleted}
          onShow={this.handleShow} />
      )
    }
  }

  public render() {
    const { todos, actions } = this.props
    const { filter } = this.state

    const filteredTodos = todos.filter(TODO_FILTERS[filter])
    const completedCount = todos.reduce((count, todo) =>
      todo.completed ? count + 1 : count,
      0
    )

    return (
      <section className="main">
        {this.renderToggleAll(completedCount)}
        <ul className="todo-list">
          {filteredTodos.map(todo =>
            <TodoItem key={todo.id} todo={todo} {...actions} />
          )}
        </ul>
        {this.renderFooter(completedCount)}
      </section>
    )
  }
}