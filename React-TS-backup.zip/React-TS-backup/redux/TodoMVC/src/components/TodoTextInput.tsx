import * as React from 'react'
import { Component } from 'react'
import * as classnames from 'classnames'

interface ITodoTextInputProps {
  onSave: (text: string) => void,
  text?: string,
  placeholder?: string,
  editing?: boolean,
  newTodo?: boolean
}

interface ITodoTextInputState {
  text: string;
}

export default class TodoTextInput extends React.Component<ITodoTextInputProps, ITodoTextInputState> {
  constructor(props: ITodoTextInputProps) {
    super(props);
    this.state = {
      text: this.props.text || ''
    };
  }

  private handleSubmit = (e: any) => {
    const text = e.target.value.trim()
    if (e.which === 13) {
      this.props.onSave(text)
      if (this.props.newTodo) {
        this.setState({ text: '' })
      }
    }
  }

  private handleChange = (e: any) => {
    this.setState({ text: e.target.value })
  }

  private handleBlur = (e: any) => {
    if (!this.props.newTodo) {
      this.props.onSave(e.target.value)
    }
  }

  public render() {
    return (
      <input className={
        classnames({
          edit: this.props.editing,
          'new-todo': this.props.newTodo
        })}
        type="text"
        placeholder={this.props.placeholder}
        autoFocus={true}
        value={this.state.text}
        onBlur={this.handleBlur}
        onChange={this.handleChange}
        onKeyDown={this.handleSubmit} />
    )
  }
}