import * as React from 'react'
import { Component } from 'react'
import * as classnames from 'classnames'
import TodoTextInput from './TodoTextInput'
import { Todo } from '../models';

interface ITodoItemProps {
  todo: Todo,
  editTodo: (id: number, text: string) => void,
  deleteTodo: (id: number) => void,
  completeTodo: (id: number) => void
}

interface ITodoItemState {
  editing: boolean;
}

export default class TodoItem extends React.Component<ITodoItemProps, ITodoItemState> {
  constructor(props: ITodoItemProps) {
    super(props);
    this.state = {
      editing: false
    };
  }

  private handleDoubleClick = () => {
    this.setState({ editing: true })
  }

  private handleSave = (id: number, text: string) => {
    if (text.length === 0) {
      this.props.deleteTodo(id)
    } else {
      this.props.editTodo(id, text)
    }
    this.setState({ editing: false })
  }

  public render() {
    const { todo, completeTodo, deleteTodo } = this.props

    let element
    if (this.state.editing) {
      element = (
        <TodoTextInput text={todo.text}
          editing={this.state.editing}
          onSave={(text: string) => this.handleSave(todo.id, text)} />
      )
    } else {
      element = (
        <div className="view">
          <input className="toggle"
            type="checkbox"
            checked={todo.completed}
            onChange={() => this.props.completeTodo(todo.id)} />
          <label onDoubleClick={this.handleDoubleClick}>
            {todo.text}
          </label>
          <button className="destroy"
            onClick={() => this.props.deleteTodo(todo.id)} />
        </div>
      )
    }

    return (
      <li className={classnames({
        completed: todo.completed,
        editing: this.state.editing
      })}>
        {element}
      </li>
    )
  }
}