import mainReducer from '../MainReducer';

describe('mainReducer', function() {
    it('should return the initial state', function() {
       expect(mainReducer(undefined, {}))
              .toEqual({location:''});
      });
 /*
      it('should react to an action with the type CHANGE_LOCATION', function() {
        var location = 'Chennai';
        expect(mainReducer(undefined, {
          type: 'CHANGE_LOCATION',
          location: location
        })).toEqual({location: location})
      });
      
  */
});
