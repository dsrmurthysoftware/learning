const initialState={location:''}
export default function mainReducer
                (state = initialState, action) {
    switch (action.type) {
      case 'CHANGE_LOCATION':
        return state.set('location', action.location);
      default:
        return state;
    }
  }
  