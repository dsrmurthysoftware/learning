/*
//Immutable js 
//Primitive type
var x=1;
var y=x;
x=2;
console.log(y);//?
//Reference type
var a={name:'sri'};
console.log(a);
var b=a;
b.name="Murthy";
console.log(a);//?

//Object.assign, $.extend , _.extend  _.assign
var c={name:'Sriram',salary:5000};
console.log(c);
var d=Object.assign({},c,{name:'Raj'})
console.log(d);

var k=[0,1,2]
var m=k.concat(4);
console.log(m);// concat,filter,map works with immutable
var j=k.filter( val=>val !=2);
console.log(j);

var p={name:"Kavitha",things:[0,1,2]}
var q=Object.assign({},p,{name:"Rama"})
console.log(q.things);
q.things.push(3)
console.log(q.things);

*/


//Level 1
// npm install redux --save
// npm install react-redux --save

import {createStore} from 'redux'
const reducer=function(state,action){
    if(action.type==='INC'){
        return state+action.payload;
    }
    if(action.type==='DEC'){
        return state-action.payload;
    }
    return state;
}
const store=createStore(reducer,0);
store.subscribe(()=>{
    console.log("Store Changed :"+store.getState())
});
store.dispatch({type:"INC",payload:1});
store.dispatch({type:"INC",payload:3});
store.dispatch({type:"DEC",payload:20});
/*

//Level 2 Middleware

//1. load applyMiddleware
import {applyMiddleware,createStore} from 'redux'
//npm install redux-logger --save-dev
import logger from "redux-logger";

const reducer=function(state,action){
    if(action.type==='INC'){
        return state+action.payload;
    }
    if(action.type==='DEC'){
        return state-action.payload;
    }else if(action.type==='E'){
        throw new Error("Ooops!!!!!!")
    }
    return state;
}
//Custom Logger middleware
const myLogger=(store)=>(next)=>(action)=>{
    console.log("Action Fired",action);
   // action.type="DEC"; //we can modify things
    next(action);
}
//Custom Error Middleware
const error=(store)=>(next)=>(action)=>{
    try{
        next(action);
    }catch(e){
        console.log('Ohhhhh..Error',e);
    }
}

const middleware=applyMiddleware(myLogger,error);

//const middleware=applyMiddleware(logger);//apply redux-logger
const store=createStore(reducer,1,middleware);

store.subscribe(()=>{
    console.log("Store Changed :"+store.getState())
});
store.dispatch({type:"INC",payload:1});
store.dispatch({type:"INC",payload:3});
store.dispatch({type:"DEC",payload:20});
store.dispatch({type:"E",payload:30})// enable for errors

*/

/*
//Level 2:Combined reducers

import {combineReducers,applyMiddleware,createStore}
           from 'redux';

//npm install  redux-devtools-extension --save-dev
import { composeWithDevTools } from 
           "redux-devtools-extension"; 

const userReducer=(state={},action)=>{   
    switch(action.type){
        case "CHANGE_NAME":{
             state.name={...state,name:action.payload};
            break;
        }
        case "CHANGE_AGE":{
            state.age={...state,age:action.payload};
            break;
        }
        default :
                  break;
    }
   return state;
}

const tweetReducer=(state=[],action)=>{      
   return state;
}

const reducers=combineReducers({
    user:userReducer,
    tweets:tweetReducer
});

const store=createStore(reducers,composeWithDevTools(
  applyMiddleware(...middleware)));

store.subscribe(()=>{
    console.log("store Changed:",store.getState());
})

store.dispatch({type:'CHANGE_NAME',payload:"Raj"});
store.dispatch({type:'CHANGE_AGE',payload:35});
*/

/*
//Level 4:  Async actions
import {applyMiddleware,createStore} from 'redux';
import logger from 'redux-logger';
import thunk from 'redux-thunk';  // npm i redux-thunk --save
import axios from 'axios';//npm i axios --save
const initialState={
    fetching:false,
    fetched:false,
    user:[],
    error:null
}
const reducer=(state=initialState,action)=>{
    switch (action.type){
        case "FETCH_USERS_START":{
            return {...state,fetching:true}
          break;
        }
        case "FETCH_USERS_ERROR":{
            return {...state,fetching:false,error:action.payload}
            break;
        }
        case "RECEIVE_USERS":{
            return {...state,
                       fetching:false,
                       fetched:true,
                       users:action.payload}
            break;
        }
        default:break;
    }
    return state;
}

const middleware=applyMiddleware(thunk,logger);
const store=createStore(reducer,middleware);

//thunk middleware expects only one dipatch
store.dispatch((dispatch)=>{
    //multiple actions occur with single action    
    //dispatch({type:'FOO'})
    //do something async here
    //dispatch({type:"BAR"})    
    dispatch({type:"FETCH_USERS_START"})

    axios.get("http://rest.learncode.academy/api/john/users")
    .then ( (response) =>{
dispatch({type:"RECEIVE_USERS",payload:response.data})
    })
    .catch((error) =>{
      dispatch({type:"FETCH_USERS_ERROR",payload:error})
    })
})
*/



import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import registerServiceWorker from './registerServiceWorker';
//npm install react-redux --save
import {Provider} from 'react-redux';

import store from "./store"

const app=document.getElementById('root');

ReactDOM.render(
    <Provider store={store}>
        <App />
     </Provider>
     ,app);

registerServiceWorker();


