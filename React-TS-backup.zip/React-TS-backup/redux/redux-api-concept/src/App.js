
import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

import {connect} from 'react-redux';

@connect( (store)=>{
   return{
     user:store.user.user
   };
})
export default class App extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">React-Redux by Murthy</h1>
        </header>
        <h1 className="App-intro">
         {this.props.user}
        Press F12 to see the output
        </h1>
      </div>
    );
  }
}

