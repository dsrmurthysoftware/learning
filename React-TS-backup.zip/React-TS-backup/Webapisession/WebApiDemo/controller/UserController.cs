﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using WebApiDemo.model;

namespace WebApiDemo.controller
{
    [Route("api/[controller]")]
    public class UsersController : Controller
    {
      
        [HttpGet]
        [Produces("application/json")]
        public User[] Get()
        {
            return new[]
            {
            new User()
            { Id = 1, Firstname = "Murthy", Lastname = "Sriram", Twitter = "@sriram" },
            new User()
            { Id = 2, Firstname = "Kiran", Lastname = "Kumar", Twitter = "@Kiran" }
           };
        }

        [HttpGet("{id}")]
        public User Get(int id)
        {
            var users = new[]
            { new User()
            { Id = 1, Firstname = "Murthy", Lastname = "Sriram", Twitter = "@sriram" },
             new User()
             { Id = 2, Firstname = "kiran", Lastname = "Kumar", Twitter = "@simonech" }
           };
            return users.FirstOrDefault(x => x.Id == id);
        }

        // Adding user 
        [HttpPost]
        [Consumes("application/xml")]
        [Produces("application/json")]
        public IActionResult CreateUser([FromBody] User user)
        {
            var users = new List<User>();
            users.Add(user);
            //  This returns the created object and the URL
            //where the client can get the user again. The status code is 201(created).
            return new CreatedResult($"/api/users/{user.Id}", user);
        }

        //[FromQuery]
       // This specifies that data comes from the payload of the HTTP request
        //Deleting user
        [HttpDelete]
        public IActionResult Delete([FromQuery] int id)
        {
            var users = new List<User>
        {
                new User()
            { Id = 1, Firstname = "Murthy", Lastname = "Sriram", Twitter = "@sriram" },
            new User()
            { Id = 2, Firstname = "Kiran", Lastname = "Kumar", Twitter = "@Kiran" }
          };
            var user = users.SingleOrDefault(x => x.Id == id);
            if (user != null)
            {
                users.Remove(user);
                //means Status Code 200 (OK). The response body is empty.
                return new EmptyResult();
            }
            //404 message that is used when the requested client can’t be found
            return new NotFoundResult();
        }
    }
}


