import { Component } from '@angular/core';
import { FormBuilder, Validators ,FormControl} from '@angular/forms';

@Component({
  selector: 'validate-form',
  templateUrl: './login.html'
})

export class LoginPageComponent {

  public loginForm = this.fb.group({
    email: ["", Validators.required],
    password: ["", Validators.required],
    otherMail:["",containsMagicWord]    //custom validator
  });

  constructor(public fb: FormBuilder) {}

  doLogin(event:any) {
    console.log(event);
    console.log(this.loginForm.value);
    let email = this.loginForm.controls.email.value
  }
}
//custom vlidator
function containsMagicWord(c: FormControl) {
    if(c.value.indexOf('magic') >= 0) {
      console.log('Invalid Mail ')
      return {
        Invalid: true
      }
    }  
    // Null means valid, believe it or not
    console.log('valid mail')
    return null
  }
  
