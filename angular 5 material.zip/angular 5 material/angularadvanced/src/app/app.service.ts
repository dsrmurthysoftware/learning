import {Injectable} from '@angular/core';

@Injectable()
export class AppService {
    company:string;
    constructor(){
        this.company="Murthy Infotek";
    }
    getCompany(){
        return this.company;
    }
}