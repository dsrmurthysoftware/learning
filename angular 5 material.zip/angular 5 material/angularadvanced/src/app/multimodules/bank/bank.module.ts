//Bank Facade
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {HomeLoanModule} from '../homeloan/homeloan.module';
import {SavingsModule} from '../savings/savings.module';

import {BankComponent} from './bank.component';
@NgModule({
  imports: [
    CommonModule,
    HomeLoanModule,
    SavingsModule
  ],
  declarations: [BankComponent],
  exports:[BankComponent]
})
export class BankModule { }
