/*

$ npm install jquery --save
$ npm install @types/jquery --save-dev   (for autocomplete)

Go to the ./angular-cli.json file at the root of 
 Angular CLI project folder, and find the scripts: [] property, 
 add this inside it:

"../node_modules/jquery/dist/jquery.min.js"

or  copy jquery-1.9.1.js to src folder and set in script folder as "../jquery-1.9.1.js"
*/

import {Component} from '@angular/core';
import {ElementRef, Inject, OnInit} from '@angular/core';

// This is required as Jquery type is not recognized by typescript
declare var $:any;
//declare var jQuery:any

@Component({
    selector: 'app-jquery',
    template:` 
   <div class='container'>
	<h1>Integrating jQuery with Angular 4.0</h1>

	<div class="info">Observe here</div>
	</div>
    `
})

export class JqueryComponent implements OnInit {
    elementRef: ElementRef;
    
    constructor(@Inject(ElementRef) elementRef: ElementRef) {
        this.elementRef = elementRef;
    }

    ngOnInit() {           
        $(this.elementRef.nativeElement)
        .find('.info')
        .html("<h1 class='text-danger'>Welcome to Murthy Infotek</h1>")
        .fadeIn(2000)
        .fadeOut(1000)
        .fadeIn(2000)
        .css('background-color','orange')
    };
}

