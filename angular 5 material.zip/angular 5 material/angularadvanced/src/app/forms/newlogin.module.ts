/*
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

//For Template Driven form
import {FormsModule} from '@angular/forms';

import { NewLoginComponent} from './newlogin.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
   
  ],
  declarations: [
  			NewLoginComponent,
  			
  ],
  exports:[
  		
  			NewLoginComponent,
  			]
})
export class NewLoginModule { }
*/