import { Component} from '@angular/core';


@Component({
  selector: 'app-template',
  template: `
    <h2 class="text-success">Template Binded Form</h2>
    
    <form  #f="ngForm" (ngSubmit)="onSubmit(f.value)">
      <label for="username">Username</label>
         <input type="text" name="username" ngModel ><br/>
               
      <label for="ssn">SSC</label>
         <input type="text" name="ssn" ngModel><br/>

      <label for="password">Password</label>
        <input type="password" name="password" ngModel><br/>
     
      <label for="pconfirm">Confirm Password</label>
        <input type="password" name="pconfirm"  ngModel>

      <button type="submit" class="btn-primary">Submit</button>
    </form>
 `  
})
export class TemplateComponent {
  onSubmit(formData:any) {
    console.log(formData);
  }
}
