import { TestBed, inject } from '@angular/core/testing';

import { AppService } from './app.service';

describe('AppService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AppService]
    });
  });

  it('App Service should be created', inject([AppService], (service: AppService) => {
    expect(service).toBeTruthy();
  }));

    it('App service should return company as Murthy Infotek', 
        inject([AppService], (service: AppService) => {
    console.log(service.getCompany()); // see the log 'Murthy Infotek'
    expect(service.getCompany()).toEqual('Murthy Infotek');
  }));
});
