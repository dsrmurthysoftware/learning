import { Component } from '@angular/core';
@Component({
    selector: 'app-test-directive',
    template: `    
    <h4 class="text-center">Custom Directive</h4>
	<h3 [hidden]="flag" class="bg-primary text-center">
	   <div>
        Welcome to Hidden Custom Attribute Directive
     </div>
	</h3>
    `
})
export class TestDirectiveComponent {
	 flag:boolean =false;  // change to true to hide
}
