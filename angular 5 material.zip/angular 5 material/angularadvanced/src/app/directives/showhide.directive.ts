// ./app/shared/hidden.directive.ts
//load DOM specific helpers
import { Directive, ElementRef, Input, Renderer } from '@angular/core';

@Directive({ selector: '[hidden]' })
export class ShowHideDirective  {
constructor(public el: ElementRef,  public renderer: Renderer) {
}

@Input() hidden: boolean;

ngOnInit(){
console.log(this.hidden);
 if(this.hidden) {
    this.renderer.setElementStyle(
              this.el.nativeElement, 'display', 'none' );
     }
   }
}



