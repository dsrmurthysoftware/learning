import {Injectable} from '@angular/core';
import {Product} from './product';
import {Http} from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';

@Injectable()
export class ProductService{
    
    constructor(private http:Http){
     
    }
    getProducts():Observable<Array<Product>>{
        return this.http.get('http://localhost:3000/store')
        .map((data:any) => {
           alert(data);
            return data.json()
        });
    }
}