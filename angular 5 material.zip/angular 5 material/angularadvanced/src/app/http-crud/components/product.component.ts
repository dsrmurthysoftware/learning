import {Component} from '@angular/core';
import {ProductService} from '../services/product.service';
import {Product} from '../services/product';

@Component({
    selector:'http-crud',
    providers:[ProductService],
    template:`<h1>Testing CRUD with HTTP in Angular</h1>`

})
export class ProductComponent{
    constructor(ps:ProductService){
        ps.getProducts().subscribe((data)=>console.log(data));
    }
}