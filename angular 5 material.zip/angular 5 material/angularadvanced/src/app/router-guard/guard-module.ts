import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { JsonpModule } from '@angular/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { routes } from './itunes.components';

import {
    GuardComponent ,
    SearchComponent,
    HomeComponent,
    HeaderComponent,
    ArtistAlbumListComponent,
    ArtistTrackListComponent,
    ArtistComponent,
    AlwaysAuthGuard,
    AlwaysAuthChildrenGuard,
    UnsearchedTermGuard
} from './itunes.components';

import {
    SearchService,
    UserService,
    OnlyLoggedInUsersGuard
} from './itunes.service';


@NgModule({
    imports: [
        CommonModule,
        ReactiveFormsModule,
        FormsModule,
        JsonpModule,
        RouterModule.forRoot(routes, { useHash: true })
    ],
    declarations: [
        GuardComponent ,
        SearchComponent,
        HomeComponent,
        HeaderComponent,
        ArtistAlbumListComponent,
        ArtistTrackListComponent,
        ArtistComponent
    ],
    providers: [
        SearchService,
        UserService,
        OnlyLoggedInUsersGuard,
        AlwaysAuthGuard,
        AlwaysAuthChildrenGuard,
        UnsearchedTermGuard
    ],
    exports: [
    GuardComponent ,
    SearchComponent,
    HomeComponent,
    HeaderComponent,
    ArtistAlbumListComponent,
    ArtistTrackListComponent,
    ArtistComponent,
    
    
    ]

})
export class GuardModule { }

