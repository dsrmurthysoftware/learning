import {TestingComponent} from './testing.component';

//Test Suite
describe ('Testing Component',()=>{
  //beforeAll
  //afterAll
  
  //hook
  beforeEach(()=>{
    this.app=new TestingComponent();
  });
  
  //afterEach(()=>{
     // will be invoked after each test call
//  })

  //Test
  it('Should have a property name  set to Murthy ',()=>{
    expect(this.app.name).toBe('Murthy');
  });
})

