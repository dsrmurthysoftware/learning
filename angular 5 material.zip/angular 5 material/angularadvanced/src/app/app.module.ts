import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';

import {ContactModule} 
      from './multicomp/contact.module'

import {LoginModule} from './login/login.module';

//Directives and Pipes
import {SharedModule} from './shared/shared.module';

import {JqueryComponent} from './jquerydemo/jquerydemo.component';

import {AppPipeComponent} from './http/asyncpipe.component';
import {AsyncPipeComponent} from './http/asyncpipe.component';

import {HttpModule} from '@angular/http';
import {JsonpModule} from '@angular/http';
import { ReactiveFormsModule} from '@angular/forms';

import {WeatherComponent} from './http/http.component';


import {MusicComponent}  from './http/music.component';
//RouterGurad module
import {GuardModule} from './router-guard/guard-module';

import {BankModule} from './multimodules/bank/bank.module';

import {FormBuilderAppComponent,FormAppComponent}
   from './forms/formbuilder.example'

import {FormBuilderComponent} from 
   './forms/formbuilder.component'


//Dynamic Injection of Component
import {HomeModule} from './dynamicinjection/home/home.module'

//import {NewLoginModule} from './forms/newlogin.module';
import { DummyComponent } from './dummy/dummy.component'

import {HttpCRUDModule} from './http-crud/http-crud.module'

import {ShowHideDirective} from './directives/showhide.directive'
import {TestDirectiveComponent} from './directives/testdirective.component'
import {TemperaturePipe} from './pipes/temparature.pipe';
import {TestPipeComponent} from './pipes/testpipe.component'

import {LoginPageComponent} from './formvalidation/loginform'
@NgModule({
  declarations: [
    AppComponent,    
    ShowHideDirective, TestDirectiveComponent,
    TemperaturePipe,TestPipeComponent,

    LoginPageComponent ,
    WeatherComponent,
    MusicComponent,
    JqueryComponent,

    FormBuilderComponent,
   
   FormBuilderAppComponent,
   FormAppComponent,
   DummyComponent,

   AppPipeComponent,
   AsyncPipeComponent
  ],
  imports: [
    BrowserModule,    
     FormsModule,

     HttpModule,
     ReactiveFormsModule,  
     
     JsonpModule,
    
     HttpCRUDModule,
    

    ContactModule,

    SharedModule,

    LoginModule,

    GuardModule,

    BankModule ,
    HomeModule,
   // NewLoginModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
