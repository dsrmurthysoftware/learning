import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dummy',
  templateUrl: './dummy.component.html',
  styleUrls: ['./dummy.component.css']
})
export class DummyComponent implements OnInit {
  company:string;
  constructor() {
    this.company='ADP Software Private Limited'
   }

  ngOnInit() {
  }

}



/*
Install Angular 4 snippets - Reload

ag-Component                   
ag-Pipe
ag-Route
ag-Service


ag-Bootstrap                     - Bootstrap snippet
ag-AppModule                     - Create the root app module (@NgModule)
ag-AppFeatureModule              - Angular app feature module (@NgModule) snippet
ag-AppFeatureRoutingModule       - Angular app feature routing module (@NgModule) snippet
ag-CanDeactivateRoutingGuard     - Create a CanDeactivate routing guard
ag-Component                     - Component snippet
ag-HttpImport                    - Http import snippet
ag-HttpClientImport              - HttpClient import snippet
ag-HttpMap                       - Http map() snippet
ag-HttpClientMap                 - HttpClient map() snippet
ag-HttpService                   - Service with Http snippet
ag-HttpClientService             - Service with HttpClient snippet
ag-InputProperty                 - @Input property snippet
ag-OutputEvent                   - @Output event snippet
ag-Pipe                          - Pipe snippet
ag-Routes                        - Angular routes snippet
ag-Route                         - Route definition snippet
ag-Service                       - Service snippet
ag-Subscribe                     - Observable subscribe snippet
HTML Snippets
ag-ClassBinding              - [class] binding snippet
ag-NgClass                   - [ngClass] snippet
ag-NgFor                     - *ngFor snippet
ag-NgForm                    - ngForm snippet
ag-NgIf                      - *ngIf snippet
ag-NgModel                   - [(ngModel)] binding snippet
ag-RouterLink                - Basic routerLink snippet
ag-RouterLinkWithParameter   - [routerLink] with route parameter snippet
ag-NgSwitch                  - [ngSwitch] snippet
ag-NgStyle                   - [ngStyle] snippet
ag-Select                    - select control using *ngFor snipppet
ag-StyleBinding              - [style] binding snippet

*/