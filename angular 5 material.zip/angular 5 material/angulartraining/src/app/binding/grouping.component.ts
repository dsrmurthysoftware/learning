import {Component} from '@angular/core';
@Component({
  selector: 'ngfor-example',
  template: `<h4>NgFor Example</h4>
<ul>
  <li *ngFor="let person of people; let i = index">
    {{ i + 1 }} - {{ person.name }}
  </li>
</ul>
 `
})
export class NgForExampleComponent {
  people: any[] = [
    {
      "name": "Murthy"
    },
    {
      "name": "Kavitha"
    },
    {
      "name": "Mallika"
    },
    {
      "name": "John"
    },
    {
      "name": "Kiran Kumar"
    }
  ];
}


@Component({
  selector: 'ngfor-grouped-example',
  template: `<h4>NgFor (grouped)</h4>
<ul *ngFor="let group of peopleByCountry">
  <li>{{ group.country }}</li>
  <ul>
    <li *ngFor="let person of group.people">
      {{ person.name }}
    </li>
  </ul>
</ul>

<br/>
<h3>NgSwitch Example</h3>
<ul *ngFor="let person of peopleCountryWise"
    [ngSwitch]="person.country"> 

  <li *ngSwitchCase="'India'" 
      class="text-success">{{ person.name }} ({{ person.country }})
  </li>
  <li *ngSwitchCase="'USA'"
      class="text-primary">{{ person.name }} ({{ person.country }})
  </li>
  <li *ngSwitchDefault 
      class="text-warning">{{ person.name }} ({{ person.country }})
  </li>
</ul>

<br/>
<h3>NgClass Example</h3>
<ul *ngFor="let person of peopleCountryWise">
  <li [ngClass]="{
    'text-success':person.country === 'UK',
    'text-primary':person.country === 'USA',
    'text-danger':person.country === 'HK'
  }">{{ person.name }} ({{ person.country }})
  </li>
</ul>


 `
})
export class NgForGroupedExampleComponent {

  peopleByCountry: any[] = [
    {
      'country': 'India',
      'people': [
        {
          "name": "Murthy"
        },
        {
          "name": "Mallika"
        },
      ]
    },
    {
      'country': 'US',
      'people': [
        {
          "name": "John"
        },
        {
          "name": "Kiran Kumar"
        },
        {
          "name": "Kavitha"
        }
      ]
    }
  ];

  peopleCountryWise: any[] = [
    {
      "name": "Douglas  Pace",
      "age": 35,
      "country": 'MARS'
    },
    {
      "name": "Mallika",
      "age": 32,
      "country": 'USA'
    },
    {
      "name": "Murthy",
      "age": 21,
      "country": 'India'
    },
    {
      "name": "Aguirre  Ellis",
      "age": 34,
      "country": 'UK'
    },
    {
      "name": "Cook",
      "age": 32,
      "country": 'USA'
    }
  ];
}
@Component({
  selector: 'app-ngFor',
  template: `
  <div class="text-left">
    <ngfor-grouped-example></ngfor-grouped-example>
    <ngfor-example></ngfor-example>
  </div>
 `
})
export class DirectivesAppComponent {
}

   