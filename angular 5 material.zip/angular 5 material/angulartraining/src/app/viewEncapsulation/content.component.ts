
import {Component,Input, Output, EventEmitter, 
  ViewEncapsulation} from '@angular/core';


class Order {
  public orderid: string;
  public info: string;
  public hide: boolean;

  constructor(orderid: string, info: string) {
    this.orderid = orderid;
    this.info = info;
    this.hide = true;
  }

  toggle() {
    this.hide = !this.hide;
  }
}


@Component({
  selector: 'Order-form',
  templateUrl: 'order.component.html',
  styleUrls: [
    'order.component.css'
  ],
  encapsulation: ViewEncapsulation.Emulated
  // encapsulation: ViewEncapsulation.Native
  // encapsulation: ViewEncapsulation.None

})
export class OrderFormComponent {
  @Output() OrderCreated = 
   new EventEmitter<Order>();

  createOrder(orderid: string, info: string) {
    this.OrderCreated.emit(new Order(orderid, info));
  }
}

@Component({
  selector: 'Order',
  template: `
<div class="card card-block">
  <h4 class="card-title">
    <ng-content select=".orderid"></ng-content>
  </h4>

  <p class="card-text"
     [hidden]="data.hide">
    <ng-content select=".info"></ng-content>
  </p>

  <a class="btn btn-primary"
     (click)="data.toggle()">Show Details
  </a>
</div>
`
})
export class OrderComponent {
  @Input('Order') data: Order;
}

@Component({
  selector: 'Order-list',
  template: `
  <h2 class="well text-center"> Multi-content Projection with ng-content</h2>
<Order-form (OrderCreated)="addOrder($event)"></Order-form>
<Order *ngFor="let j of Orders" [Order]="j">
  <span class="orderid">{{ j.orderid }}</span>
  <h1 class="info">{{ j.info }}</h1>
</Order>
  `
})
export class OrderListComponent {
  Orders: Order[];

  constructor() {
    this.Orders = [
      new Order("101", "monitor purchase"),
      new Order("102", "Buy systems"),
      new Order("103", "purchase of stablizer")
    ];
  }

  addOrder(Order) {
    this.Orders.unshift(Order);
  }
}


@Component({
  selector: 'app-content',
  template: `
    <Order-list></Order-list>
  `
})
export class ContentComponent {
}


