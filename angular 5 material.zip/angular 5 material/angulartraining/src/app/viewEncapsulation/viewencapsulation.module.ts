/*
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {ViewEncapsulationComponent,
        OrderFormComponent,
        OrderComponent,
        OrderListComponent} 
        from './viewencapsulation.component'


@NgModule({
  imports:      [CommonModule],
  declarations: [   
        ViewEncapsulationComponent,
        OrderFormComponent,
        OrderComponent,
        OrderListComponent  
                     
                ],
  exports:      [  
        ViewEncapsulationComponent,
        OrderFormComponent,
        OrderComponent,
        OrderListComponent  
                    ]                    
})
export class VEModule { }

*/



