
import {Component, NgModule, Input, 
       Output, EventEmitter, 
       ViewEncapsulation} from '@angular/core';

export class Order {
  public orderid: string;
  public info: string;
  public hide: boolean;

  constructor(orderid: string, info: string) {
    this.orderid = orderid;
    this.info = info;
    this.hide = true;
  }

  toggle() {
    this.hide = !this.hide;
  }
}


@Component({
  selector: 'Order-form',
  templateUrl: 'order.component.html',
  styleUrls: [
    'order.component.css'
  ],
  encapsulation: ViewEncapsulation.Emulated
  // encapsulation: ViewEncapsulation.Native
  // encapsulation: ViewEncapsulation.None

})
export class OrderFormComponent {
  @Output() OrderCreated = new EventEmitter<Order>();

  createOrder(orderid: string, info: string) {
    this.OrderCreated.emit(new Order(orderid, info));
  }
}

@Component({
  selector: 'Order',
  template: `
<div class="card card-block">
  <h4 class="card-title">{{data.orderid}}</h4>
  <p class="card-text"
     [hidden]="data.hide">{{data.info}}</p>
  <a (click)="data.toggle()"
     class="btn btn-warning">Show Details
  </a>
</div>
`
})
export class OrderComponent {
  @Input('Order') data: Order;
}

@Component({
  selector: 'Order-list',
  template: `
  <h2 class="well text-center">View Encapsulation </h2>
<Order-form (OrderCreated)="addOrder($event)"></Order-form>
<Order *ngFor="let j of Orders" [Order]="j"></Order>
  `
})
export class OrderListComponent {
  Orders: Order[];

  constructor() {
    this.Orders = [
      new Order("101", "monitor purchase"),
      new Order("102", "Buy systems"),
      new Order("103", "purchase of stablizer"),
    ];
  }

  addOrder(Order) {
    this.Orders.unshift(Order);
  }
}


@Component({
  selector: 'app-viewEncapsulation',
  template: `
       <Order-list></Order-list>
  `
})
export class ViewEncapsulationComponent {
}

