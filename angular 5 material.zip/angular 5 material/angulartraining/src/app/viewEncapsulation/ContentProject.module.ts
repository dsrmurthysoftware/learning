import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {
        ContentComponent,
        OrderFormComponent,
        OrderComponent,
        OrderListComponent} 
        from './content.component'


@NgModule({
  imports:      [CommonModule],
  declarations: [   
        ContentComponent,
        OrderFormComponent,
        OrderComponent,
        OrderListComponent  
                     
                ],
  exports:      [  
        ContentComponent,
        OrderFormComponent,
        OrderComponent,
        OrderListComponent  
                    ]                    
})
export class ContentProjectionModule { }





