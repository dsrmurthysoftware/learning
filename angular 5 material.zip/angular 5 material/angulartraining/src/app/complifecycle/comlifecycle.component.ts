//Component Life Cycle
import { Component, 
             Input,OnInit,OnChanges,DoCheck,OnDestroy,
            ChangeDetectorRef} from '@angular/core';

// Parent component
@Component({
  selector: 'app-lifecycle',
  template: `
    <h3 class="container">Google Search:
        <input type="text" [(ngModel)]="search">
     </h3>
    <child [search]="search"></child>
  `
})
//Parent Component
export class CompLifeCycleComponent {
  search: string = 'Computers';
}

//child component
@Component({
  selector: 'child',
  template: `
  <h2 class='text-danger container'>Search Text</h2>
  <div class='well'>
   <h3 class='text-primary'>{{search}}</h3>
  </div>
    `
})
export class ChildComponent implements 
           OnInit,OnChanges,DoCheck,OnDestroy {
             
  @Input() search: string;
  // search isn't initialized yet 
  constructor(public cd:ChangeDetectorRef) {//token
    // inject service here
    console.log(`constructor: ${this.search}`);
    this.cd.detach();
  }
  // ChangeDetectRef methods: 
  // detach(), reattach(), detectChanges(), checkNoChanges() 

 ngOnInit() { // invoked only once
   // invoke service method for initial data or raise custom events here
    console.log(`1. ngOnInit: ${this.search}`);
   /*
    setTimeout(() => {
      this.cd.reattach()
    },5000); 
    */
  }
  //Invoked every time an @Input() property changes via the data binding 
  ngOnChanges() {
   // invoke service method to handle changes or perform validations
    console.log(`2. ngOnChanges: ${this.search}`);
  }  
  ngDoCheck() {
    // Write custom change detection strategy logic here
    console.log("3. ngDoCheck- Change detection strategy")
    //to re-render even it is detached in constructor 
     //this.cd.detectChanges();
  //this.cd.checkNoChanges();//safe guard changes
  } 
  ngAfterContentInit() {
    console.log("4.Component content has been initialized");
  }
  ngAfterContentChecked() {
    console.log("5.Component content has been Checked");
  }
  ngAfterViewInit() {
    console.log("6.Component views are initialized");
  }
  ngAfterViewChecked() {
    console.log("7.Component views have been checked");
  }
  ngOnDestroy() {
    // Remove the component state here, unsubscribe observer,log
    console.log("8.Component Destroyed");
    // unsubscribe events are observer
  }
}//end of code
