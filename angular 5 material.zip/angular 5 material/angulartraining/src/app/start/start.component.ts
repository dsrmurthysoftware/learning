import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-start',
  templateUrl: './start.component.html',
  styleUrls: ['./start.component.css'],
  styles: [`
    h3 {
        text-decoration:underline;
    }
`]
})
export class StartComponent implements OnInit {
   time:any;
   name:string='Sriram';
   buttonStatus:boolean = false;
   titleStyle = 'red'; // by default any
   model:any={email:'murthy@gmail.com'}
   
  constructor() {
     window.setInterval(() => {
                this.time=new Date().toString()
        }, 1000)
   }  
      //hook
  ngOnInit() {
    console.log("start component is initialized")
  }
// methods   - Event handlers
  Save(event:any){
    alert("Ok.. Your points are redeemed")
    this.buttonStatus=true
  }
}



//https://developer.mozilla.org/en-US/docs/Web/Events


