import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';



import {TestCompComponent} from
      './testcomp/testcomp.component'





import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppComponent } from './app.component';
import {GreetComponent} from './greet/greet.component'


import { StartComponent } from './start/start.component';

import {SimpleComponent} from './test/simple.component';

//binding
import {DropDownComponent} from './binding/dropdown.component';

import {BindingComponent} from "./binding/binding.component";
import {NestedComponent} from "./binding/nested.component";

import {DebugComponent} from "./debug/debug.component"

import {HighlightComponent } from "./binding/highlightrow.component";

//Working with IOModule
import {IOModule} from './input-output/input-output.module';

//Dependency Injection
import {DIModule} from './di/di.module';

import {ViewchildModule} from './viewchild/viewchild.module';

import {SkillsModule} from './skills/skills.module';
import {LoginModule} from './login/login.module';


import {CompLifeCycleComponent,ChildComponent} 
     from './complifecycle/comlifecycle.component';

import {AnimateComponent} from './animation/animation.component'

//import {VEModule} from './viewencapsulation/viewencapsulation.module'
import {ContentProjectionModule} from 
    './viewEncapsulation/contentproject.module'

import {    NgForExampleComponent,
    NgForGroupedExampleComponent,
    DirectivesAppComponent} from './binding/grouping.component';
import { DummyComponent } from './dummy/dummy.component'

@NgModule({
  declarations: [
    AppComponent, GreetComponent,
    StartComponent,


    TestCompComponent,


    BindingComponent,        
    NestedComponent,

    DebugComponent,
    SimpleComponent,
    DropDownComponent,
    HighlightComponent ,

    CompLifeCycleComponent,
    ChildComponent,
   
    AnimateComponent,

    NgForExampleComponent,
    NgForGroupedExampleComponent,
    DirectivesAppComponent,
    DummyComponent
  ],
  imports: [
    BrowserModule,FormsModule,   
    IOModule,    

    DIModule,

    ViewchildModule,
    
    SkillsModule,
    LoginModule,
    
    BrowserAnimationsModule,
    //VEModule,
    ContentProjectionModule   

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
