import {Component} from '@angular/core'
@Component({
  selector:'app-testcomp',
 template:`
      <h1 class="container text-danger text-center">
         Welcome to Test Component Mr. {{name}}
     </h1> 
 `
})
export class TestCompComponent{
    name:string;
    constructor(){
        this.name='Murthy';
    }
}