import {Component} from '@angular/core'

@Component({
    selector:'app-greet',
    template:`
                <h1 style="background:yellow:color:blue">
                 {{msg}}
                 </h1>
    `
})
export class GreetComponent{
    msg:string
    constructor(){
        this.msg="Welcome to Angular 4.0"
    }
}