import { AngullartestingPage } from './app.po';

describe('angullartesting App', () => {
  let page: AngullartestingPage;

  beforeEach(() => {
    page = new AngullartestingPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!!');
  });
});
