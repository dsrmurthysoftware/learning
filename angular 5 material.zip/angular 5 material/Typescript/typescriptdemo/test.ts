function logMsg(message){
    console.log(message);
}
logMsg("welcome");