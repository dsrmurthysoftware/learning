import React from 'react'
import ProductsContainer from './ProductsContainer'
import CartContainer from './CartContainer'
import Header from '../components/Header'
import Footer from '../components/Footer'

const App = () => (
  <div>
    
    <Header/>
    <hr/>
    <div className="bg-warning text-center">
    <ProductsContainer  />
    </div>
    <hr/>
    <div className="bg-success text-center">
    <CartContainer />
    </div>
    
    <Footer/>
  </div>
)

export default App