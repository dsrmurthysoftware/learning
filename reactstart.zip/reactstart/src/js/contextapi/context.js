import React from "react";

//This is global context state
const state = {
  number: 0,
  authToken:'Adfd3999',
  sessionId:''
};
 const NumberContext = React.createContext(state.number);
 //passing initial value
 
export default NumberContext;
