To build for production purpose

To run test

npm run test

npm run build

observe dist folder and files in it