import { Component} from '@angular/core';

@Component({
  selector: 'app-start',
  templateUrl: './start.component.html',
  styleUrls: ['./start.component.css'],
  styles: [`
    h3 {
        text-decoration:underline;
    }
`]
})
export class StartComponent {
   time:any;
   name:string="Murthy";
   buttonStatus1:boolean = false;
   titleStyle = 'red';
   
  constructor() {
     window.setInterval(() => {
                this.time=new Date().toString()
        }, 1000)
   }
  
//https://developer.mozilla.org/en-US/docs/Web/Events
  Save(event:any){
    console.log("saved the details")
    this.buttonStatus1=true;
    alert("Details are saved.. Button disabled")
  }
}
