"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
//StockComponent
var StockComponent = (function () {
    //Parent component
    function StockComponent() {
    }
    // this is event.target.value in  javascript
    StockComponent.prototype.onInputEvent = function (_a) {
        var target = _a.target;
        this.stock = target.value;
    };
    return StockComponent;
}());
StockComponent = __decorate([
    core_1.Component({
        selector: 'app-stock',
        template: "\n    <div class=\"text-left\">\n    <h1 class='bg-info'>Stock Exchange</h1>\n    <input type=\"text\" \n      placeholder=\"Enter stock (e.g: Verizon)\"  \n      (change)=\"onInputEvent($event)\">\n    <br/>\n   \n       <order-processor [stockSymbol]=\"stock\" quantity=\"100\">\n       </order-processor>\n    </div>\n        <timer-comp></timer-comp>\n  "
    })
], StockComponent);
exports.StockComponent = StockComponent;
