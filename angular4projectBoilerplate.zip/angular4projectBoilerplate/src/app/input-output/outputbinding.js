"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
// child component
var PriceQuoterComponent = (function () {
    function PriceQuoterComponent() {
        var _this = this;
        this.lastPriceEvent = new core_1.EventEmitter();
        this.stockSymbol = "Verizon";
        window.setInterval(function () {
            var priceQuote = {
                stockSymbol: _this.stockSymbol,
                lastPrice: 100 * Math.random()
            };
            _this.price = priceQuote.lastPrice;
            _this.lastPriceEvent.emit(priceQuote); //Raise Event
        }, 1000);
    }
    return PriceQuoterComponent;
}());
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], PriceQuoterComponent.prototype, "lastPriceEvent", void 0);
PriceQuoterComponent = __decorate([
    core_1.Component({
        selector: 'price-quoter',
        template: "<h3 class=\"well text-danger\">\n                Child PriceQuoterComponent:\n                      {{stockSymbol}} \n                      {{price | currency:'USD':'1.2'}}\n               </h3>\n               "
    }),
    __metadata("design:paramtypes", [])
], PriceQuoterComponent);
exports.PriceQuoterComponent = PriceQuoterComponent;
// parent component
var OutputComponent = (function () {
    function OutputComponent() {
        this.stockInfo = { 'stockSymbol': '', 'lastPrice': 0 };
    }
    OutputComponent.prototype.priceQuoteHandler = function (event) {
        this.stockSymbol = event.stockSymbol;
        this.price = event.lastPrice;
        this.stockInfo =
            { 'stockSymbol': event.stockSymbol, 'lastPrice': event.lastPrice };
    };
    return OutputComponent;
}());
OutputComponent = __decorate([
    core_1.Component({
        selector: 'app-event',
        template: "\n    <div class='container'>\n        <h1 class='text-success'>\n        Parent Component received: \n        {{stockSymbol}} {{price | currency:'USD':true:'1.2'}}\n        </h1>\n\n       <price-quoter (lastPriceEvent)=\"priceQuoteHandler($event)\">\n       </price-quoter>   \n\n       <app-mail  [info]=\"stockInfo\"></app-mail> \n    </div>\n    "
    })
], OutputComponent);
exports.OutputComponent = OutputComponent;
// Do it: Add MailComponent as child to root component
// and input data to display message information
var MailComponent = (function () {
    function MailComponent() {
    }
    return MailComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], MailComponent.prototype, "info", void 0);
MailComponent = __decorate([
    core_1.Component({
        selector: 'app-mail',
        template: "\n    <div class='container'>\n        <h3 class='text-primary'>\n        Sent mail about {{info.stockSymbol}}\n         and Stock value    {{info.lastPrice | currency:'USD':'1.2'}} \n         successfully.\n           </h3>\n    </div>\n    "
    })
], MailComponent);
exports.MailComponent = MailComponent;
