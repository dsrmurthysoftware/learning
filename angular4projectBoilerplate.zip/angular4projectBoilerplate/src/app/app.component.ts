import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
 <!-- Put your components here-->

<app-stock></app-stock>
  
  `,
})
export class AppComponent  { 
  name = 'Angular'; 
}
