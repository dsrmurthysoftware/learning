"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var DropDownComponent = (function () {
    function DropDownComponent() {
        this.products = [
            { "id": 1, "name": "Monitor" },
            { "id": 2, "name": "Keyboard" },
            { "id": 3, "name": "Mouse" }
        ];
        this.selectedProduct = this.products[0];
    }
    DropDownComponent.prototype.onSelect = function (productId) {
        this.selectedProduct = null;
        for (var i = 0; i < this.products.length; i++) {
            if (this.products[i].id == productId) {
                this.selectedProduct = this.products[i];
            }
        }
    };
    return DropDownComponent;
}());
DropDownComponent = __decorate([
    core_1.Component({
        selector: 'app-dropdown',
        template: "\n     <h3>Select your product to buy</h3>\n    <select (change)=\"onSelect($event.target.value)\">\n      <option *ngFor=\"let product of products\" [value]=\"product.id\">\n         {{product.name}}\n      </option>\n    </select>\n    <br/>\n   \n    <h2 class=\"well\">Thanks for selecting   {{selectedProduct.name}}</h2>\n    "
    })
], DropDownComponent);
exports.DropDownComponent = DropDownComponent;
