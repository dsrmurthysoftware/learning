/*
Steps :
     Debuggin in Chrome :
         - Run the app and press F12 to open debugger of Chrome
         - click Sources tab -> app -> debug -> debug.component.ts
         - click on line 32 and insert break point and refresh.
         - click the increment button and observe callstack... and counter value
         - or click Augury, select DebugComponent,
           and click View source link (right side),
           put BP and refresh to run .
           
    Augury:
         - install augury chrome extension
         - click augury and refresh. observe state : counter=1. (you can change)
         - see the injector graph, ngModules
         - observe elements tab and fadein/fadeout as you click
    
    Debuggin in VS Code:
        
        -  click debug icon and select Launch chrome against localhost
        - observe launch.json and set your app port to 3000 or 4200.
        - click DEBUG in VS code which will start app in debug mode
        - click play button to continue (F5) in vs code (it is not error)
        - click increment button in chrome and switch to VS code and observe varibles /events....
        - again click play button in Chrome (F8 to resume) - Observe in VS code
        
*/
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var DebugComponent = (function () {
    function DebugComponent() {
        this.counter = 1;
    }
    DebugComponent.prototype.increment = function (event) {
        this.counter = this.counter + 1;
    };
    return DebugComponent;
}());
DebugComponent = __decorate([
    core_1.Component({
        selector: 'app-debug',
        template: "\n     <h3>Debugging Angular app</h3>\n     <button (click)=\"increment($event)\" \n            class=\"btn btn-primary\">Increment\n      </button>\n     <h4 class=\"well\">{{counter}}</h4>\n    "
    }),
    __metadata("design:paramtypes", [])
], DebugComponent);
exports.DebugComponent = DebugComponent;
