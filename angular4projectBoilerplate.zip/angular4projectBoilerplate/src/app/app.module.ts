import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms'

import { AppComponent }  from './app.component';
import {TestComponent} from './test/test.component'

import {StartModule} from './start/start.module'
//start
import {BindingComponent} from './binding/binding.component'
import {NestedComponent} from './binding/nested.component'

import {IOModule} from './input-output/input-output.module'

import {DebugComponent} from './debug/debug.component'
@NgModule({
  imports:      [ BrowserModule,FormsModule,
                  StartModule,
                  IOModule
                    ],
  declarations: [ AppComponent,
                  TestComponent, 
                  DebugComponent,                       
                  BindingComponent,
                  NestedComponent
                    ],

  bootstrap:    [ AppComponent ]
})
export class AppModule { }
