import { Component } from '@angular/core';

@Component({
  selector: 'app-test',
  template:`
    <h1 class="text-success">{{info}}</h1>
  `
})
export class TestComponent {
  info:string = 'Testing Angular Component';
}
