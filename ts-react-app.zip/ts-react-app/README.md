# React-Webpack-Typescript

A simple starter framework for running these three things in harmony, hopefully.

This repo includes
- `react`
- `react-dom`

## Getting Started

Install all the things
```
$ npm i
```

Run the webpack dev server
```
$ npm run start
```

or

```
$ yarn start
```

Navigate to `localhost:3000` in your browser and you're good to go.

## TODO

- Add testing (Jest)
- Add stying somehow
- Add PROD and DEV env
- JS minification for PROD env
- Redux?

## Tutorials that helped
- [Getting started with ReactJs Typescript and Webpack](https://medium.com/@fay_jai/getting-started-with-reactjs-typescript-and-webpack-95dcaa0ed33c)
- [React & Webpack - Microsoft](https://www.typescriptlang.org/docs/handbook/react-&-webpack.html)
