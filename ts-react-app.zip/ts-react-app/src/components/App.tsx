import * as React from "react";
import FirstComponent from './FirstComponent';
import UserComponent from './UserComponent';
import Vehicle from './vehicle';

export class App extends React.Component<any, any> {
  render() {
    return <div>
      Hello, {this.props.name}
      <FirstComponent/>
      <Vehicle vehicleType="Car" color="Red" numWheels={4} age={5} />
      <Vehicle vehicleType="Motorcycle" color="Blue" numWheels={2} age={10} />
      <UserComponent 
          name="Logrocket" 
          age={105} 
          address="get me if you can" 
          dob={new Date()} />
    </div>;
  }
}


